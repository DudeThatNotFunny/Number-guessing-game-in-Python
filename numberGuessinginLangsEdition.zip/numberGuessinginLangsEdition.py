import xml.etree.cElementTree as ET
import os,random
clear = lambda: os.system('cls')
clear()

langList = []
tree = ET.parse('lang/lang.xml')
root = tree.getroot()
for lang in root.findall("lang"):
    langList.append(lang.get("language"))

language = input(f"Choose your language {langList}: ")
clear()

langs = {}
get = ["wrongInt","rangeTxt","guessInt","Victory","try1","try2","continue","toHigh","toLow"]
countTries = 0
#language = "lv"
x = random.randint(1,100)


for lang in root.findall("lang"):
    if(lang.get("language") == language):
        for i in range(len(get)):
            langs.update({get[i]: lang.find(get[i]).text})
    #else: print(lang.get("language"))

glang = langs.get

print(f"{glang('rangeTxt')}\n{glang('guessInt')}")

def isItInt(x):
    try:
        int(x)
    except:
        clear()
        return False
        
while True:
    inputData = input()
    if(isItInt(inputData)==False):
        print(f"{glang('wrongInt')}\n{glang('rangeTxt')}\n{glang('guessInt')}")
        continue
    inputData = int(inputData)
    if(inputData == x):
        clear()
        print(glang('Victory'),"\n",glang('try1'), countTries, glang('try2'),"\n",glang('continue'))
        x = random.randint(1,100)
        countTries = 0
        continue
    elif(inputData > x):
        clear()
        countTries += 1
        print(glang('toHigh'),"\n",glang('guessInt'))
    elif(inputData < x):
        clear()
        countTries += 1
        print(glang('toLow'),"\n",glang('guessInt'))